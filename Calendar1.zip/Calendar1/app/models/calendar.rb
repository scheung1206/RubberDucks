class Calendar < ActiveRecord::Base
  has_many :events 
end
