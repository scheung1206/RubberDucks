class Post < ActiveRecord::Base
  belongs_to :event
end
